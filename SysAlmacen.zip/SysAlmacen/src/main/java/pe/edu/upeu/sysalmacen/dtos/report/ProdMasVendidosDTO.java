package pe.edu.upeu.sysalmacen.dtos.report;

public interface ProdMasVendidosDTO {
    String getNombre();
    Double getPu();
    Double getCantidad();
    Double getBasimp();
    Double getIgv();
    Double getImporte();
}
